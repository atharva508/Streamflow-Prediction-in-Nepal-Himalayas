#!/bin/bash

# Define the different values for n_steps_out and corresponding output_prefix
n_steps_out_values=(1 3 7 30)
output_prefix_suffix=("1day" "3day" "7day" "30day")

# Define the Model types
model_types=("TRANSFORMER" "SEQ2SEQ" "CNN_RNN")  # All supported models


# model_types=("Enhanced_Transformer" "Seq2Seq")  # All supported models


# Create a folder for the configuration files if it doesn't exist
config_folder="config_files"
mkdir -p $config_folder

# Path to the base config file
base_config="config.yml"

# Loop over the Model types and the different n_steps_out values
for model_type in "${model_types[@]}"; do
    for i in "${!n_steps_out_values[@]}"; do
        # Set the n_steps_out and output_prefix for this run
        n_steps_out=${n_steps_out_values[$i]}
        output_suffix=${output_prefix_suffix[$i]}
        
        # Construct the output prefix using Model type and day suffix
        output_prefix="NP_${model_type}_${output_suffix}"
        
        # Construct the filename for the config file
        config_file="${config_folder}/config_${output_prefix}_nsteps_${n_steps_out}.yml"
        
        # Create a new config file for this run by copying the base config
        cp "$base_config" "$config_file"
        
        # Modify the copied config file using | as the delimiter to avoid conflicts
        sed -i "s|^n_steps_out:.*|n_steps_out: $n_steps_out|" "$config_file"
        sed -i "s|^output_prefix:.*|output_prefix: \"$output_prefix\"|" "$config_file"
        sed -i "s|^model_type:.*|model_type: \"$model_type\"|" "$config_file"
        
        # Submit the job and pass the specific config file as an argument
        sbatch submit_jobs.sh "$config_file"
        
        echo "Submitted job with model_type: $model_type, n_steps_out: $n_steps_out, and output_prefix: $output_prefix using $config_file"
    done
done

